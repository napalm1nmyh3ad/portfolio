function scrollToAbout() {
  const t017 = document.querySelector('.t017');
  t017.scrollIntoView({ behavior: "smooth" });
}